﻿// ConteÃºdo das seÃ§Ãµes - edite aqui para adicionar ou modificar slides
const slides = [
    {
        tipo: "experiencia",
        conteudo: {
            nome: "Prof. Me. MAXIMIANO EDUARDO PEREIRA",
            foto: "max.png",
            badge: "ExperiÃªncia Profissional",
            titulo: "ExperiÃªncia de Campo e InteligÃªncia ðŸ›¡ï¸",
            cards: [
                {
                    titulo: "Infraestrutura CrÃ­tica",
                    itens: [
                        "ðŸ”¹ <strong>IBM UNIX & Linux:</strong> AdministraÃ§Ã£o de sistemas e CPD nos anos 2000.",
                        "ðŸ”¹ <strong>ComunicaÃ§Ã£o Satelital:</strong> ImplantaÃ§Ã£o de redes de dados fabris."
                    ]
                },
                {
                    titulo: "InteligÃªncia e GAECO",
                    itens: [
                        "ðŸ”¹ <strong>PMMG (Desde 2002):</strong> AnÃ¡lise criminal e suporte Ã  decisÃ£o via Big Data.",
                        "ðŸ”¹ <strong>LABFOR GAECO:</strong> ResponsÃ¡vel TÃ©cnico e Perito em mÃ­dias digitais.",
                        "ðŸ”¹ <strong>CertificaÃ§Ã£o Cellebrite:</strong> ExtraÃ§Ã£o avanÃ§ada e combate ao crime organizado."
                    ]
                }
            ]
        }
    },
    {
        tipo: "academico",
        conteudo: {
            badge: "AcadÃªmico & Pesquisa",
            titulo: "Percurso AcadÃªmico e DocÃªncia ðŸŽ“",
            cards: [
                {
                    titulo: "Pesquisa e TÃ­tulos",
                    itens: [
                        "âœ… <strong>Doutorando/Mestre</strong> em Sist. Computacionais (UFU).",
                        "âœ… Esp. em <strong>ComputaÃ§Ã£o Forense</strong> (IFTM).",
                        "âœ… Esp. em <strong>InteligÃªncia de SeguranÃ§a</strong> (IFSULDEMINAS).",
                        "âœ… Esp. em <strong>IoT e AutomaÃ§Ã£o</strong> (Anhanguera)."
                    ]
                },
                {
                    titulo: "Ensino Superior",
                    itens: [
                        "ðŸ‘¨â€ðŸ« <strong>UNCISAL:</strong> PÃ³s em SeguranÃ§a e Forense.",
                        "ðŸ‘¨â€ðŸ« <strong>Grupo Cogna:</strong> GraduaÃ§Ã£o em Tecnologia.",
                        "ðŸ‘¨â€ðŸ« <strong>Instrutor PMMG:</strong> CapacitaÃ§Ã£o tÃ©cnica operacional."
                    ]
                }
            ],
            citacao: "Buscando a convergÃªncia entre o rigor cientÃ­fico e a prÃ¡tica de campo."
        }
    },
{
    "tipo": "topicoTexto",
    "conteudo": {
        "emoji": "ðŸ“",
        "titulo": "Plano de Curso",
        "subtitulo": "Nossa jornada pelos fundamentos da anÃ¡lise forense digitalðŸ’ª",
        "layout": "duas_colunas",
        "colunas": [
            {
                "nome": "Coluna 1",
                "topicos": [
                    { "titulo": "1. IntroduÃ§Ã£o Ã  AnÃ¡lise Forense", "texto": "Conceitos, Fundamentos, Ã‰tica e Legalidade." },
                    { "titulo": "2. Coleta e PreservaÃ§Ã£o", "texto": "Cadeia de CustÃ³dia e Boas PrÃ¡ticas." },
                    { "titulo": "3. Sistemas de Arquivos", "texto": "Estruturas e RecuperaÃ§Ã£o de Dados." }
                ]
            },
            {
                "nome": "Coluna 2",
                "topicos": [
                    { "titulo": "4. AnÃ¡lise de Logs e MemÃ³ria", "texto": "Sistemas e MemÃ³ria VolÃ¡til." },
                    { "titulo": "5. Ferramentas Forenses", "texto": "Softwares e TÃ©cnicas de AnÃ¡lise." },
                    { "titulo": "6. InvestigaÃ§Ã£o e RelatÃ³rios", "texto": "Metodologias e Laudos Periciais." }
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ“âœ¨",
        titulo: "A EvoluÃ§Ã£o TecnolÃ³gica",
        subtitulo: "Da vÃ¡lvula ao rastro digital: a evoluÃ§Ã£o que moldou a perÃ­cia forense",
        topicos: [
            { titulo: "VÃ¡lvulas (O InÃ­cio)", texto: "MÃ¡quinas monumentais (ENIAC). Processamento binÃ¡rio puro, sem armazenamento persistente como conhecemos; a 'perÃ­cia' seria puramente fÃ­sica/elÃ©trica." },
            { titulo: "Transistores (A MiniaturizaÃ§Ã£o)", texto: "SubstituiÃ§Ã£o das vÃ¡lvulas. Maior confiabilidade e surgimento das memÃ³rias magnÃ©ticas (os primÃ³rdios do que viria a ser o HD" },
            { titulo: "Microchips (Circuitos Integrados)", texto: "Milhares de transistores em uma pastilha de silÃ­cio. InÃ­cio do processamento em massa e padronizaÃ§Ã£o de arquiteturas." }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ“âœ¨",
        titulo: "A Era da Conectividade e Mobilidade",
        subtitulo: "Novas tecnologias, Internet, IA",
        topicos: [
            { titulo: "Computador Pessoal (PC)", texto: "A computaÃ§Ã£o chega Ã s mesas e lares. Surgem os sistemas de arquivos (FAT, NTFS) e a necessidade de recuperar dados deletados em discos locais." },
            { titulo: "Internet (A Grande Teia)", texto: "A evidÃªncia sai do isolamento. Surgem os crimes de rede, logs de acesso e a anÃ¡lise forense de trÃ¡fego de dados (TCP/IP)." },
            { titulo: "Hoje (Ubiquidade e Nuvem)", texto: "Dispositivos menores que a palma da mÃ£o, criptografia de hardware e dados fragmentados em servidores globais. A anÃ¡lise Ã© multidispositivo." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "",
        titulo: "AnÃ¡lise ForenseðŸ›ï¸",
        subtitulo: "",
        topicos: [
            {
                titulo: "Origem",
                texto: "O termo Forense vem do latim forensis, que se refere ao fÃ³rum. Na Roma Antiga, o fÃ³rum era o local onde as disputas judiciais aconteciam. Portanto, anÃ¡lise forense Ã©, por definiÃ§Ã£o, qualquer anÃ¡lise tÃ©cnica ou cientÃ­fica feita para ser utilizada em um tribunal.",
                itens: []
            },
            {
                titulo: "DefiniÃ§Ã£o",
                texto: "Ã‰ o conjunto de mÃ©todos cientÃ­ficos utilizados para examinar vestÃ­gios, objetos e locais, com o objetivo de responder a trÃªs perguntas fundamentais para a justiÃ§a: ",
                itens: [
                        "<strong>O que aconteceu?</strong> (A dinÃ¢mica do evento)",
                        "<strong>Como aconteceu?</strong> (O mÃ©todo utilizado)",
                        "<strong>Quem estava envolvido?</strong> (A autoria)"
                    ]
            }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "",
        titulo: "As Ãreas ClÃ¡ssicas (NÃ£o Digitais)",
        subtitulo: "",
        topicos: [
            {
                titulo: "",
                texto: "Antes de falarmos de bits, a anÃ¡lise forense jÃ¡ resolvia crimes atravÃ©s de:",
                itens: [
                    "<strong>CriminalÃ­stica</strong> Exame do local do crime, anÃ¡lise de manchas de sangue (serologia) e balÃ­stica.",
                    "<strong>Papiloscopia</strong> O estudo das impressÃµes digitais para identificaÃ§Ã£o humana.",
                    "<strong>Medicina Legal </strong> AutÃ³psias e exames de corpo de delito para determinar a causa da morte ou lesÃµes.",
                    "<strong>Grafotecnia </strong> AnÃ¡lise de escritas e assinaturas para detectar falsificaÃ§Ãµes.",
                    "<strong>Toxicologia </strong> IdentificaÃ§Ã£o de substÃ¢ncias quÃ­micas, drogas ou venenos no organismo.",
                    "<strong>Entomologia </strong>O estudo de insetos encontrados em cadÃ¡veres para determinar o tempo da morte."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "",
        titulo: "AnÃ¡lise ForenseðŸ›ï¸ x AnÃ¡lise Forense DigitalðŸ›ï¸ðŸ“±",
        subtitulo: "",
        topicos: [

            {
                titulo: "A anÃ¡lise forense se diferencia de uma anÃ¡lise cientÃ­fica comum por causa do rigor legal",
                texto: "Na ciÃªncia comum, se vocÃª comete um erro, vocÃª refaz o experimento. Na anÃ¡lise forense, se vocÃª quebra a Cadeia de CustÃ³dia (o registro de quem tocou na prova), a prova Ã© anulada e o criminoso pode ser solto, mesmo que a anÃ¡lise esteja correta.",
                itens: []
            }
        ]
    }
},

// --- UNIDADE 02 ---
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "âš–ï¸",
        titulo: "UNIDADE 02 - Coleta e preservaÃ§Ã£o de evidÃªncias",
        subtitulo: "PrincÃ­pios e prÃ¡ticas da coleta e preservaÃ§Ã£o de evidÃªncias",
        topicos: [
            { titulo: "Principal FundamentaÃ§Ã£o", texto: "Norma ISO/IEC 27037" },
            { titulo: "Atores Principais", texto: "Quem vai manusear a evidÃªncia" },
            { titulo: "Pilares da EvidÃªncia Digital", texto: "Principais pontos a serem observados" },
            { titulo: "Principios Fundamentais", texto: "Garantindo a validade cientÃ­fica do processo" },
            { titulo: "Fases Principais", texto: "Principais etapas do procedimento tÃ©cnico" },
            { titulo: "Casos Especiais", texto: "Quando o sistema nÃ£o pode ser desligado" },
            { titulo: "Cadeia de CustÃ³dia", texto: "O coraÃ§Ã£o da perÃ­cia judicial" }
        ]
    }
},

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "âš–ï¸",
        titulo: "A Norma ISO/IEC 27037",
        subtitulo: "O PadrÃ£o Ouro na PreservaÃ§Ã£o de EvidÃªncias Digitais",
        topicos: [
            { titulo: "O que Ã©?", texto: "Diretriz internacional para identificaÃ§Ã£o, coleta, aquisiÃ§Ã£o e preservaÃ§Ã£o de evidÃªncia digital. Essencial para garantir a admissibilidade jurÃ­dica." },
            { titulo: "Objetivo Principal", texto: "Padronizar o tratamento da evidÃªncia para que ela tenha forÃ§a probatÃ³ria, mantendo integridade e autenticidade desde a cena do crime atÃ© o tribunal." },
            { titulo: "AplicaÃ§Ã£o Reativa", texto: "A norma foca em medidas tomadas *apÃ³s* a ocorrÃªncia de um incidente ou crime." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ‘¤",
        titulo: "Atores da ISO 27037",
        subtitulo: "Quem manipula a evidÃªncia?",
        topicos: [
            {
                titulo: "Categorias de IndivÃ­duos",
                texto: "A norma divide as responsabilidades conforme o nÃ­vel de especializaÃ§Ã£o:",
                itens: [
                    "<strong>Interventores (DEFR):</strong> Digital Evidence First Responders. TÃªm conhecimento para auxiliar no manuseio inicial sem destruir provas.",
                    "<strong>Especialistas (DES):</strong> Digital Evidence Specialists. Profissionais experientes (Peritos) que garantem a preservaÃ§Ã£o tÃ©cnica complexa."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ’Ž",
        titulo: "Os 3 Pilares da EvidÃªncia Digital",
        subtitulo: "Para ser vÃ¡lida, a evidÃªncia deve ser:",
        topicos: [
            { titulo: "1. RelevÃ¢ncia", texto: "Deve provar ou refutar um elemento central do caso investigado." },
            { titulo: "2. Confiabilidade", texto: "O processo deve garantir que a evidÃªncia seja exatamente o que pretende ser (sem adulteraÃ§Ã£o)." },
            { titulo: "3. SuficiÃªncia", texto: "A prova deve ser completa o bastante para permitir uma investigaÃ§Ã£o adequada do fato." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "âš™ï¸",
        titulo: "PrincÃ­pios Fundamentais (MÃ©todo)",
        subtitulo: "Garantindo a validade cientÃ­fica do processo",
        topicos: [
            {
                titulo: "Tratamento TÃ©cnico",
                texto: "A ISO 27037 exige quatro aspectos no tratamento:",
                itens: [
                    "<strong>Auditabilidade:</strong> Documentar tudo para que o processo possa ser avaliado por terceiros.",
                    "<strong>Repetibilidade:</strong> Mesmos mÃ©todos e instrumentos devem gerar o mesmo resultado.",
                    "<strong>Reprodutibilidade:</strong> Diferentes instrumentos/condiÃ§Ãµes devem chegar ao mesmo resultado (ex: Hash).",
                    "<strong>Justificabilidade:</strong> Todas as aÃ§Ãµes devem ter uma razÃ£o tÃ©cnica lÃ³gica e documentada."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ”",
        titulo: "Fase 1: IdentificaÃ§Ã£o",
        subtitulo: "Onde o rastro comeÃ§a",
        topicos: [
            { titulo: "Busca e Reconhecimento", texto: "Identificar dispositivos fÃ­sicos (HDs, Celulares) e lÃ³gicos (arquivos, partiÃ§Ãµes) que contenham dados relevantes." },
            { titulo: "PriorizaÃ§Ã£o de Volatilidade", texto: "Decidir o que coletar primeiro com base no risco de perda (MemÃ³ria RAM antes de HD, por exemplo)." },
            { titulo: "Regra de Ouro", texto: "Se estÃ¡ desligado, nÃ£o ligue. Se estÃ¡ ligado, nÃ£o desligue (atÃ© avaliar o risco de perda de dados volÃ¡teis)." }
        ]
    }
},

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ“¦",
        titulo: "Fase 2 & 3: Coleta e AquisiÃ§Ã£o",
        subtitulo: "Extraindo a prova com rigor",
        topicos: [
            { titulo: "Coleta (FÃ­sica)", texto: "Recolher o dispositivo fÃ­sico da cena para o laboratÃ³rio. Exige embalagem antiestÃ¡tica e lacres." },
            { titulo: "AquisiÃ§Ã£o (LÃ³gica)", texto: "Criar a cÃ³pia forense (imagem). Deve-se usar funÃ§Ãµes de <strong>HASH (MD5, SHA-256)</strong> para provar que a cÃ³pia Ã© idÃªntica ao original." },
            { titulo: "EspaÃ§o nÃ£o alocado", texto: "A aquisiÃ§Ã£o deve tentar capturar dados deletados (espaÃ§o slack/unallocated) sempre que possÃ­vel." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "â›“ï¸",
        titulo: "A Cadeia de CustÃ³dia",
        subtitulo: "O coraÃ§Ã£o da perÃ­cia judicial",
        topicos: [
            {
                titulo: "Rastreabilidade Total",
                texto: "Documento cronolÃ³gico que registra todo o histÃ³rico da evidÃªncia:",
                itens: [
                    "Identificador Ãºnico da evidÃªncia.",
                    "Quem acessou, quando (data/hora) e onde (local).",
                    "Registros de entrada e saÃ­da de salas de custÃ³dia.",
                    "Justificativa para qualquer alteraÃ§Ã£o inevitÃ¡vel (ex: aquisiÃ§Ã£o de sistema ligado)."
                ]
            }
        ]
    }
},

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ›¡ï¸",
        titulo: "Fase 4: PreservaÃ§Ã£o",
        subtitulo: "Protegendo contra o tempo e o homem",
        topicos: [
            { titulo: "EspoliaÃ§Ã£o", texto: "Proteger contra degradaÃ§Ã£o magnÃ©tica, calor, umidade e vibraÃ§Ãµes que podem corromper os bits." },
            { titulo: "AdulteraÃ§Ã£o", texto: "Evitar mudanÃ§as intencionais. Uso de bloqueadores de escrita (Write Blockers) Ã© mandatÃ³rio." },
            { titulo: "CustÃ³dia Segura", texto: "Armazenamento em cofres ou salas com acesso restrito e monitorado (CFTV)." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸš€",
        titulo: "Casos Especiais: MissÃ£o CrÃ­tica",
        subtitulo: "Quando nÃ£o podemos desligar o sistema",
        topicos: [
            {
                titulo: "Servidores e Hospitais",
                texto: "Dispositivos que nÃ£o podem parar exigem abordagens diferentes:",
                itens: [
                    "<strong>AquisiÃ§Ã£o Parcial:</strong> Quando o volume de dados Ã© massivo ou hÃ¡ restriÃ§Ã£o legal (mandado especÃ­fico).",
                    "<strong>AquisiÃ§Ã£o Imediata (Live):</strong> Coleta de dados da RAM enquanto o sistema roda. Vital para recuperar chaves de criptografia e conexÃµes ativas."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "âœ…",
        titulo: "ConclusÃ£o do MÃ³dulo",
        subtitulo: "Seguir a norma nÃ£o Ã© burocracia, Ã© seguranÃ§a jurÃ­dica",
        topicos: [
            { titulo: "Integridade", texto: "Sem o rastro da ISO 27037, a perÃ­cia Ã© apenas uma opiniÃ£o tÃ©cnica vulnerÃ¡vel a questionamentos." },
            { titulo: "PrÃ³ximos Passos", texto: "Agora que sabemos como coletar, vamos entender os Sistemas de Arquivos (FAT, NTFS, EXT) para saber onde os dados se escondem." }
        ]
    }
},


// --- MÃ“DULO 3: SISTEMAS DE ARQUIVOS E ARMAZENAMENTO ---
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "âš–ï¸",
        titulo: "UNIDADE 03 - Sistemas de Arquivos e Armazenamento",
        subtitulo: "A arquitetura onde a evidÃªncia reside",
        topicos: [
            { titulo: "Sistemas de Arquivos", texto: "Como o dado Ã© organizado (NTFS, EXT4, FAT) e onde a evidÃªncia se esconde." },
            { titulo: "DinÃ¢mica do Armazenamento", texto: "Clusters, Slack Space e a evoluÃ§Ã£o para o Big Data Forense." },
            { titulo: "RecuperaÃ§Ã£o de Dados", texto: "TÃ©cnicas de File Carving e os desafios dos dispositivos modernos (SSD/TRIM)." }
        ]
    }
},

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ’¾",
        titulo: "Sistemas de Arquivos e Armazenamento",
        subtitulo: "A arquitetura onde a evidÃªncia reside",
        topicos: [
            { titulo: "O que Ã© um File System?", texto: "Ã‰ o mÃ©todo e a estrutura de dados que o sistema operacional utiliza para controlar como os dados sÃ£o armazenados e recuperados." },
            { titulo: "AbstraÃ§Ã£o Forense", texto: "Para o usuÃ¡rio, Ã© um arquivo. Para o perito, sÃ£o clusters, setores, inodes e metadados organizados em uma estrutura lÃ³gica especÃ­fica." },
            { titulo: "ImportÃ¢ncia", texto: "Entender o sistema de arquivos Ã© o que permite recuperar dados que o suspeito acredita ter apagado para sempre." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ“ˆ",
        titulo: "A ExplosÃ£o do Armazenamento",
        subtitulo: "Do disquete ao Big Data Forense",
        topicos: [
            {
                titulo: "A EvoluÃ§Ã£o da Capacidade",
                texto: "O desafio forense mudou de escala drasticamente:",
                itens: [
                    "<strong>Anos 90/00:</strong> Disquetes (1.44MB) e HDs de poucos GB. PerÃ­cia rÃ¡pida, bit-a-bit.",
                    "<strong>Era Atual:</strong> SSDs de TBs, NVMe ultravelozes e storages em nuvem.",
                    "<strong>Desafio Big Data:</strong> Analisar volumes massivos de dados exige ferramentas de triagem (Triage) e indexaÃ§Ã£o avanÃ§ada, pois a cÃ³pia bit-a-bit de Petabytes Ã© inviÃ¡vel."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ—ï¸",
        titulo: "Estruturas de Sistemas de Arquivos",
        subtitulo: "Principais arquiteturas encontradas em campo",
        topicos: [
            { titulo: "Windows (FAT32 / NTFS)", texto: "O NTFS utiliza a MFT (Master File Table), um banco de dados interno que armazena metadados cruciais para a perÃ­cia." },
            { titulo: "Linux (EXT4 / XFS)", texto: "Baseados em Inodes. Separam o nome do arquivo do seu conteÃºdo fÃ­sico no disco." },
            { titulo: "Apple (APFS)", texto: "Otimizado para Flash/SSD, utiliza 'Copy-on-Write' e criptografia nativa de sistema." }
        ]
    }
},

{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ§±",
        titulo: "Anatomia do Armazenamento",
        subtitulo: "Como o dado Ã© organizado fisicamente",
        topicos: [
            {
                titulo: "Conceitos Fundamentais",
                texto: "A base da recuperaÃ§Ã£o de dados:",
                itens: [
                    "<strong>Setor:</strong> A menor unidade fÃ­sica (geralmente 512 bytes ou 4KB).",
                    "<strong>Cluster:</strong> Conjunto de setores. Ã‰ a menor unidade lÃ³gica que o SO consegue ler.",
                    "<strong>Slack Space:</strong> O 'espaÃ§o desperdiÃ§ado' entre o fim do arquivo e o fim do cluster. Um esconderijo clÃ¡ssico para evidÃªncias!",
                    "<strong>Unallocated Space:</strong> EspaÃ§o marcado como 'livre' pelo SO, mas que ainda contÃ©m dados de arquivos deletados."
                ]
            }
        ]
    }
},

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ©¹",
        titulo: "RecuperaÃ§Ã£o de Dados (Data Recovery)",
        subtitulo: "Trazendo o invisÃ­vel de volta Ã  luz",
        topicos: [
            { titulo: "DeleÃ§Ã£o LÃ³gica vs. FÃ­sica", texto: "Quando vocÃª 'apaga' um arquivo, o SO apenas remove o ponteiro. Os bits continuam no disco atÃ© serem sobrescritos." },
            { titulo: "File Carving", texto: "TÃ©cnica de recuperaÃ§Ã£o que nÃ£o usa o sistema de arquivos. Ela busca por 'Assinaturas de CabeÃ§alho' (Magic Bytes). Ex: Todo JPEG comeÃ§a com 'FF D8 FF'." },
            { titulo: "Desafio SSD (TRIM)", texto: "Diferente dos HDs, SSDs modernos limpam setores deletados automaticamente via comando TRIM, dificultando a recuperaÃ§Ã£o." }
        ]
    }
},

{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ›¡ï¸",
        titulo: "A EvidÃªncia no Big Data",
        subtitulo: "EstratÃ©gias para grandes volumes",
        topicos: [
            {
                titulo: "Forense em Escala",
                texto: "Como o Prof. Maximiano aplica isso em cenÃ¡rios complexos:",
                itens: [
                    "<strong>Hash Filtering:</strong> Eliminar arquivos conhecidos (SO, DLLs) para focar apenas no que o usuÃ¡rio criou.",
                    "<strong>Timeline Analysis:</strong> Cruzar metadados de criaÃ§Ã£o, modificaÃ§Ã£o e acesso (MAC times) para reconstruir eventos.",
                    "<strong>Data Mining Forense:</strong> Uso de IA e scripts para encontrar padrÃµes em milhÃµes de logs de sistemas distribuÃ­dos."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ",
        titulo: "Resumo do MÃ³dulo",
        subtitulo: "Domine a base, entenda o rastro",
        topicos: [
            { titulo: "O Sistema de Arquivos Ã© o Mapa", texto: "Sem entender a estrutura (NTFS, EXT4), o perito estÃ¡ cego." },
            { titulo: "A RecuperaÃ§Ã£o Ã© TÃ©cnica", texto: "O File Carving Ã© a Ãºltima linha de defesa quando o sistema de arquivos estÃ¡ corrompido ou formatado." },
            { titulo: "PrÃ³ximo Passo", texto: "Agora que sabemos onde os arquivos ficam, vamos aprender a analisar os logs e a memÃ³ria volÃ¡til (RAM)." }
        ]
    }
},

// --- MÃ“DULO 4: ANÃLISE DE LOGS E MEMÃ“RIA ---

// --- MÃ“DULO 4: ANÃLISE DE LOGS E MEMÃ“RIA ---

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ§ ",
        titulo: "UNIDADE 04 - AnÃ¡lise de Logs e MemÃ³ria",
        subtitulo: "Rastros volÃ¡teis e registros de atividades",
        topicos: [
            { titulo: "MemÃ³ria VolÃ¡til vs. NÃ£o-VolÃ¡til", texto: "A natureza dos dados e a ordem de volatilidade." },
            { titulo: "Forense de MemÃ³ria (RAM)", texto: "Capturando processos, senhas e chaves de criptografia em tempo real." },
            { titulo: "Logs de Sistemas", texto: "A linha do tempo dos eventos: quem, quando e onde." },
            { titulo: "A EvoluÃ§Ã£o dos Registros", texto: "Dos logs locais Ã  centralizaÃ§Ã£o em SIEM e Cloud." },
            { titulo: "Estados de Dispositivos", texto: "O desafio tÃ©cnico dos estados BFU e AFU em perÃ­cia mÃ³vel." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "âš¡",
        titulo: "A Natureza da MemÃ³ria",
        subtitulo: "Onde os dados 'evaporam'",
        topicos: [
            {
                titulo: "Volatilidade: O Grande Desafio",
                texto: "Diferente do disco rÃ­gido, a RAM depende de energia para manter a informaÃ§Ã£o:",
                itens: [
                    "<strong>MemÃ³ria RAM:</strong> Armazena processos ativos, conexÃµes de rede e senhas abertas.",
                    "<strong>EvoluÃ§Ã£o:</strong> De megabytes a centenas de gigabytes; analisar um 'dump' moderno exige ferramentas de alta performance.",
                    "<strong>Dados na Nuvem:</strong> Muitas vezes, logs de acesso e memÃ³ria de instÃ¢ncias volÃ¡teis sÃ£o as Ãºnicas provas em crimes SaaS."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ§ª",
        titulo: "O 'Santo Graal' da RAM",
        subtitulo: "O que encontramos no Dump de MemÃ³ria",
        topicos: [
            { titulo: "Processos Ocultos", texto: "Malwares 'fileless' que rodam apenas na RAM e nÃ£o deixam rastros no disco." },
            { titulo: "Criptografia", texto: "Chaves de BitLocker ou VeraCrypt frequentemente residem na RAM enquanto o sistema estÃ¡ aberto." },
            { titulo: "Artefatos Recentes", texto: "HistÃ³rico de navegaÃ§Ã£o anÃ´nima e documentos nÃ£o salvos que nunca chegaram ao HD." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ“œ",
        titulo: "Logs: A Caixa-Preta do Sistema",
        subtitulo: "Reconstruindo a linha do tempo",
        topicos: [
            {
                titulo: "Tipos de Registros",
                texto: "Onde o perito busca a autoria e a cronologia:",
                itens: [
                    "<strong>Windows Event Logs:</strong> Registros de logons, falhas e criaÃ§Ã£o de serviÃ§os.",
                    "<strong>Syslog (Linux):</strong> AutenticaÃ§Ãµes SSH e mensagens crÃ­ticas do kernel.",
                    "<strong>SIEM & Cloud:</strong> CentralizaÃ§Ã£o de logs (Splunk/ELK) para anÃ¡lise de Big Data e correlaÃ§Ã£o de eventos globais."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ“±",
        titulo: "Estados de Dispositivos MÃ³veis",
        subtitulo: "BFU vs. AFU: O cenÃ¡rio real da perÃ­cia",
        topicos: [
            {
                titulo: "BFU (Before First Unlock)",
                texto: "Aparelho reiniciado, aguardando a primeira senha:",
                itens: [
                    "Criptografia forte ativa; chaves ainda nÃ£o carregadas na RAM.",
                    "ExtraÃ§Ã£o extremamente limitada para o perito."
                ]
            },
            {
                titulo: "AFU (After First Unlock)",
                texto: "UsuÃ¡rio jÃ¡ desbloqueou o aparelho ao menos uma vez apÃ³s ligar:",
                itens: [
                    "<strong>Chaves na RAM:</strong> Mesmo bloqueado, as chaves de descriptografia estÃ£o acessÃ­veis para ferramentas avanÃ§adas (ex: Cellebrite).",
                    "<strong>Risco:</strong> Se o aparelho desligar ou reiniciar por inatividade, ele volta ao estado BFU."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ›¡ï¸",
        titulo: "SeguranÃ§a Ativa em Smartphones",
        subtitulo: "Mecanismos de defesa modernos",
        topicos: [
            { titulo: "Inactivity Reboot", texto: "Recurso que forÃ§a o reinÃ­cio automÃ¡tico apÃ³s X horas sem uso, 'trancando' o aparelho em BFU." },
            { titulo: "USB Restricted Mode", texto: "Desativa a porta de dados do iPhone apÃ³s perÃ­odo de inatividade, bloqueando ferramentas forenses." },
            { titulo: "Boas PrÃ¡ticas", texto: "Uso de Capas de Faraday e manutenÃ§Ã£o constante de energia (Power Banks) para preservar o estado AFU." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ› ï¸",
        titulo: "Ferramentas de AnÃ¡lise",
        subtitulo: "O arsenal para anÃ¡lise de Logs e RAM",
        topicos: [
            {
                titulo: "Softwares PadrÃ£o de Mercado",
                texto: "Tecnologia a favor da investigaÃ§Ã£o:",
                itens: [
                    "<strong>Volatility:</strong> Framework lÃ­der para anÃ¡lise forense de memÃ³ria.",
                    "<strong>FTK Imager:</strong> Coleta de RAM e imagem de disco.",
                    "<strong>Cellebrite Premium:</strong> ExploraÃ§Ã£o de estados AFU em dispositivos mÃ³veis.",
                    "<strong>Splunk / Graylog:</strong> GestÃ£o e anÃ¡lise de logs em larga escala (Big Data)."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ",
        titulo: "Resumo do MÃ³dulo 04",
        subtitulo: "A volatilidade como oportunidade",
        topicos: [
            { titulo: "A RAM Ã© a Verdade", texto: "O disco diz o que foi feito; a memÃ³ria diz o que estÃ¡ sendo feito agora." },
            { titulo: "PreservaÃ§Ã£o MÃ³vel", texto: "Entender BFU/AFU Ã© a diferenÃ§a entre uma extraÃ§Ã£o completa e um dispositivo inacessÃ­vel." },
            { titulo: "Rumo ao PrÃ³ximo NÃ­vel", texto: "Com os dados coletados e os logs analisados, vamos agora dominar as ferramentas que automatizam esse fluxo." }
        ]
    }
},

// --- MÃ“DULO 5: FERRAMENTAS E TÃ‰CNICAS DE ANÃLISE ---

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ› ï¸",
        titulo: "UNIDADE 05 - Ferramentas de ComputaÃ§Ã£o Forense",
        subtitulo: "O arsenal tÃ©cnico do perito digital",
        topicos: [
            { titulo: "Ecossistema de Ferramentas", texto: "DiferenciaÃ§Ã£o entre softwares proprietÃ¡rios (pagos) e open-source (livres)." },
            { titulo: "EspecializaÃ§Ã£o por Ativo", texto: "Ferramentas focadas em Discos (HD/SSD), Mobile, Nuvem, Web e DVR." },
            { titulo: "Hardwares Forenses", texto: "Bloqueadores de escrita, duplicadores e laboratÃ³rios de campo." },
            { titulo: "A Integridade Digital", texto: "O papel do Hash como 'impressÃ£o digital' da prova." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ’°",
        titulo: "Softwares ProprietÃ¡rios (Pagos)",
        subtitulo: "LÃ­deres de mercado e alto desempenho",
        topicos: [
            {
                titulo: "SuÃ­tes de InvestigaÃ§Ã£o",
                texto: "Ferramentas robustas com suporte e validaÃ§Ã£o jurÃ­dica:",
                itens: [
                    "<strong>Cellebrite Premium:</strong> LÃ­der absoluta em Mobile. Capaz de realizar extraÃ§Ãµes fÃ­sicas e contornar bloqueios complexos.",
                    "<strong>Magnet AXIOM:</strong> Excelente para integrar evidÃªncias de smartphone, computador e nuvem em uma Ãºnica timeline.",
                    "<strong>PC-3000 (Tcheca):</strong> O 'padrÃ£o ouro' para recuperaÃ§Ã£o de dados em HDs com falha fÃ­sica e reparo de firmware.",
                    "<strong>Belkasoft Evidence Center:</strong> Especializado em anÃ¡lise de artefatos de redes sociais e mensageiros."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ§",
        titulo: "Software Livre e Iniciativas Nacionais",
        subtitulo: "Poder analÃ­tico sem custo de licenciamento",
        topicos: [
            {
                titulo: "Ferramentas Abertas e Governamentais",
                texto: "SoluÃ§Ãµes amplamente validadas pela comunidade:",
                itens: [
                    "<strong>IPED (PolÃ­cia Federal):</strong> Ferramenta brasileira de alta performance para processamento e indexaÃ§Ã£o de grandes volumes de dados.",
                    "<strong>Autopsy / Sleuth Kit:</strong> Interface grÃ¡fica amigÃ¡vel e extensÃ­vel para anÃ¡lise de sistemas de arquivos.",
                    "<strong>Paladin (Linux):</strong> Uma distro 'bootÃ¡vel' forense baseada em Ubuntu, pronta para triagem e imagem de discos.",
                    "<strong>FTK Imager (Lite):</strong> O padrÃ£o para criaÃ§Ã£o de imagens forenses e triagem rÃ¡pida de arquivos."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸŒ",
        titulo: "Ferramentas Especializadas",
        subtitulo: "Onde o generalismo nÃ£o alcanÃ§a",
        topicos: [
            { titulo: "Web Forensics (Hunchly)", texto: "Captura automÃ¡tica de pÃ¡ginas web, preservando metadados e garantindo que a prova online nÃ£o 'desapareÃ§a'." },
            { titulo: "Cloud Forensics", texto: "Ferramentas como o Magnet Cloud para coletar dados diretamente de contas Google, iCloud e Office 365." },
            { titulo: "DVR Forensics", texto: "Softwares especÃ­ficos para extrair vÃ­deos de sistemas de monitoramento (CFTV) que possuem sistemas de arquivos proprietÃ¡rios." },
            { titulo: "iOS Time Pause", texto: "TÃ©cnicas e ferramentas para 'congelar' o tempo interno do iPhone, evitando bloqueios por inatividade ou reboots programados." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ›¡ï¸",
        titulo: "TÃ©cnicas de Campo e PreservaÃ§Ã£o",
        subtitulo: "Garantindo a custÃ³dia antes do laboratÃ³rio",
        topicos: [
            {
                titulo: "Ambiente Controlado",
                texto: "Equipamentos que evitam a contaminaÃ§Ã£o da prova:",
                itens: [
                    "<strong>Faraday (Gaiola/Capa):</strong> Bloqueio total de sinais (RF/WiFi/Bluetooth) para impedir comandos remotos de 'wipe'.",
                    "<strong>Modo AviÃ£o:</strong> Primeira aÃ§Ã£o em dispositivos mÃ³veis para isolar o rÃ¡dio, quando o acesso Ã© possÃ­vel.",
                    "<strong>Write Blockers:</strong> Hardware que impede fisicamente que o sistema operacional escreva qualquer bit no disco sob anÃ¡lise."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "#ï¸âƒ£",
        titulo: "O Algoritmo de Hash",
        subtitulo: "A pedra angular da autenticidade",
        topicos: [
            { titulo: "O que Ã©?", texto: "Uma funÃ§Ã£o matemÃ¡tica que transforma qualquer volume de dados em uma sequÃªncia alfanumÃ©rica Ãºnica de tamanho fixo (ex: MD5, SHA-1, SHA-256)." },
            { titulo: "Para que serve?", texto: "Garantir a integridade. Se um Ãºnico bit for alterado no arquivo, o Hash muda completamente (efeito avalanche)." },
            { titulo: "Na JustiÃ§a", texto: "O perito calcula o Hash no momento da coleta e no momento da entrega do laudo. Se os hashes batem, a prova Ã© a mesma; se divergem, a prova foi adulterada." }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ",
        titulo: "Resumo do MÃ³dulo 05",
        subtitulo: "Tecnologia a serviÃ§o da verdade",
        topicos: [
            { titulo: "NÃ£o existe ferramenta Ãºnica", texto: "O perito deve saber qual software aplicar para cada tipo de ativo (HD, Mobile, Web)." },
            { titulo: "Rigor acima de tudo", texto: "Bloqueadores de escrita e o uso correto do Hash sÃ£o o que diferencia uma perÃ­cia de uma simples cÃ³pia de arquivos." },
            { titulo: "PrÃ³ximo Passo", texto: "Agora que dominamos as ferramentas, vamos para o encerramento: Metodologias de InvestigaÃ§Ã£o e ElaboraÃ§Ã£o de RelatÃ³rios." }
        ]
    }
},

// --- MÃ“DULO 6: INVESTIGAÃ‡ÃƒO E RELATÃ“RIOS ---

{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "âš–ï¸",
        titulo: "UNIDADE 06 - InvestigaÃ§Ã£o e RelatÃ³rios",
        subtitulo: "A materializaÃ§Ã£o da prova e o rigor metodolÃ³gico",
        topicos: [
            { titulo: "Metodologias de InvestigaÃ§Ã£o", texto: "Processos estruturados para garantir que nenhum detalhe seja esquecido." },
            { titulo: "AnÃ¡lise de Dados", texto: "Transformando dados brutos em informaÃ§Ãµes inteligÃ­veis para a justiÃ§a." },
            { titulo: "ElaboraÃ§Ã£o de RelatÃ³rios", texto: "A arte de traduzir o 'tecniquÃªs' para o magistrado e advogados." },
            { titulo: "Ã‰tica e Imparcialidade", texto: "O papel do perito como auxiliar da justiÃ§a, nÃ£o da acusaÃ§Ã£o ou defesa." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ“‰",
        titulo: "Metodologias de InvestigaÃ§Ã£o",
        subtitulo: "Seguindo padrÃµes internacionais",
        topicos: [
            {
                titulo: "Fluxo de Trabalho Forense",
                texto: "As fases que dÃ£o suporte Ã  investigaÃ§Ã£o:",
                itens: [
                    "<strong>PreparaÃ§Ã£o:</strong> Planejamento da abordagem e check-list de equipamentos.",
                    "<strong>Exame:</strong> AplicaÃ§Ã£o das ferramentas (que vimos no mÃ³dulo 5) para extrair os dados.",
                    "<strong>AnÃ¡lise:</strong> A fase intelectual. Cruzar logs, metadados e arquivos para responder aos quesitos.",
                    "<strong>ApresentaÃ§Ã£o:</strong> A consolidaÃ§Ã£o de tudo no documento final."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ•µï¸",
        titulo: "TÃ©cnicas de AnÃ¡lise",
        subtitulo: "Onde o perito 'conversa' com os dados",
        topicos: [
            { titulo: "AnÃ¡lise Temporal (Timeline)", texto: "Reconstruir a ordem dos fatos. O que aconteceu antes e depois do incidente?" },
            { titulo: "AnÃ¡lise de VÃ­nculos", texto: "Cruzar contatos, e-mails e transferÃªncias para identificar organizaÃ§Ãµes criminosas (essencial no GAECO)." },
            { titulo: "AnÃ¡lise de Palavras-Chave", texto: "Uso de expressÃµes regulares (Regex) para encontrar padrÃµes como CPFs, placas de veÃ­culos ou termos especÃ­ficos do crime." }
        ]
    }
},
{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "âœï¸",
        titulo: "O Laudo Pericial Forense",
        subtitulo: "A voz do perito no processo judicial",
        topicos: [
            {
                titulo: "Estrutura do Documento",
                texto: "Um relatÃ³rio profissional deve conter:",
                itens: [
                    "<strong>PreÃ¢mbulo:</strong> IdentificaÃ§Ã£o das autoridades, perito e objeto (celular, HD, etc).",
                    "<strong>HistÃ³rico:</strong> Contexto da investigaÃ§Ã£o e do recebimento da prova.",
                    "<strong>Metodologia:</strong> Quais ferramentas e tÃ©cnicas foram usadas (ex: Cellebrite, Hash SHA-256).",
                    "<strong>Resposta aos Quesitos:</strong> Respostas diretas Ã s perguntas feitas pela autoridade ou pelas partes.",
                    "<strong>ConclusÃ£o:</strong> O parecer tÃ©cnico final do perito."
                ]
            }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸš«",
        titulo: "Erros Comuns na Relatoria",
        subtitulo: "O que pode anular seu trabalho",
        topicos: [
            { titulo: "Subjetividade", texto: "Nunca use 'eu acho' ou 'parece'. O laudo deve ser baseado em evidÃªncias extraÃ­veis e repetÃ­veis." },
            { titulo: "Linguagem excessivamente tÃ©cnica", texto: "O juiz nÃ£o precisa saber o que Ã© um 'ponteiro de inode', ele precisa saber se o arquivo foi deletado propositalmente." },
            { titulo: "Falha na Cadeia de CustÃ³dia", texto: "NÃ£o documentar quem manuseou a prova entre a coleta e a anÃ¡lise invalida o laudo." }
        ]
    }
},
{
    tipo: "topicoTexto",
    conteudo: {
        emoji: "ðŸ",
        titulo: "Encerramento do Curso",
        subtitulo: "A ConvergÃªncia entre CiÃªncia e JustiÃ§a",
        topicos: [
            { titulo: "A PerÃ­cia como Pilar", texto: "Em um mundo digital, a prova pericial tecnolÃ³gica Ã©, muitas vezes, a Ãºnica prova irrefutÃ¡vel." },
            { titulo: "EvoluÃ§Ã£o ContÃ­nua", texto: "Novas criptografias e IAs surgem a cada dia. O perito nunca para de estudar." },
            { titulo: "Mensagem Final", texto: " 'A perÃ­cia digital nÃ£o busca culpados, busca a verdade contida nos bits.' " }
        ]
    }
},

// --- SIMULADO COMPLETO: 30 QUESTÃ•ES (UNIDADES 1 A 6) ---

{
    tipo: "topicoTextoItens",
    conteudo: {
        emoji: "ðŸ“",
        titulo: "A ImportÃ¢ncia da FixaÃ§Ã£o TÃ©cnica",
        subtitulo: "Por que realizar os simulados com rigor?",
        topicos: [
            {
                titulo: "SimulaÃ§Ã£o do ContraditÃ³rio",
                texto: "Na perÃ­cia real, seu trabalho serÃ¡ questionado por assistentes tÃ©cnicos e advogados. O simulado antecipa esse desafio:",
                itens: [
                    "<strong>ValidaÃ§Ã£o do Conhecimento:</strong> Garante que termos como BFU, AFU e Hash nÃ£o sejam apenas siglas, mas conceitos dominados.",
                    "<strong>PrecisÃ£o TerminolÃ³gica:</strong> Um erro de conceito em um laudo pode anular uma prova inteira. As questÃµes treinam o uso da palavra correta.",
                    "<strong>Agilidade AnalÃ­tica:</strong> Automatiza o raciocÃ­nio para que, no local de crime, a tomada de decisÃ£o seja rÃ¡pida e segura.",
                    "<strong>PreparaÃ§Ã£o para CertificaÃ§Ãµes:</strong> Muitas questÃµes seguem o padrÃ£o de provas internacionais (EnCE, ACE, IACIS) e concursos pÃºblicos."
                ]
            }
        ]
    }
},

// --- UNIDADE 01: INTRODUÃ‡ÃƒO E FUNDAMENTOS ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 1",
        subtitulo: "Unidade 01: Fundamentos",
        pergunta: "Qual Ã© o objetivo principal que define uma anÃ¡lise como verdadeiramente forense?",
        opcoes: [
            "A capacidade de recuperar arquivos deletados.",
            "A aplicaÃ§Ã£o de mÃ©todos cientÃ­ficos para que a prova suporte o contraditÃ³rio judicial.",
            "O uso exclusivo de ferramentas pagas de alta tecnologia.",
            "A identificaÃ§Ã£o imediata do culpado sem necessidade de processo."
        ],
        dica: "Lembre-se: Forense vem de FÃ³rum.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 2",
        subtitulo: "Unidade 01: PrincÃ­pio de Locard",
        pergunta: "Sobre o PrincÃ­pio de Locard aplicado ao mundo digital, qual afirmaÃ§Ã£o Ã© correta?",
        opcoes: [
            "Todo contato ou aÃ§Ã£o deixa um rastro, mesmo que seja o registro da prÃ³pria deleÃ§Ã£o.",
            "No ambiente digital Ã© impossÃ­vel deixar rastros.",
            "O rastro digital sÃ³ existe se o usuÃ¡rio estiver conectado Ã  internet.",
            "Rastros digitais sÃ£o apagados permanentemente ao desligar o PC."
        ],
        dica: "Todo contato deixa um rastro - logs, metadados, temporÃ¡rios.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 3",
        subtitulo: "Unidade 01: Ã‰tica",
        pergunta: "Qual Ã© a principal responsabilidade Ã©tica do perito digital?",
        opcoes: [
            "Garantir a condenaÃ§Ã£o do suspeito a qualquer custo.",
            "Analisar todos os arquivos pessoais, mesmo os irrelevantes ao caso.",
            "Manter a imparcialidade, limitando-se aos fatos tÃ©cnicos extraÃ­veis.",
            "Alterar a evidÃªncia para tornÃ¡-la mais compreensÃ­vel."
        ],
        dica: "O perito trabalha para a verdade, nÃ£o para a polÃ­cia ou defesa.",
        respostaCorreta: 2
    }
,
Cole este conteÃºdo no arquivo conteudo.js, substituindo desde a linha "// --- UNIDADE 01: INTRODUÃ‡ÃƒO E FUNDAMENTOS ---" atÃ© o final do array (antes do ];):

// --- UNIDADE 01: INTRODUÃ‡ÃƒO E FUNDAMENTOS ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 1",
        subtitulo: "Unidade 01: Fundamentos",
        pergunta: "Qual Ã© o objetivo principal que define uma anÃ¡lise como verdadeiramente forense?",
        opcoes: [
            "A capacidade de recuperar arquivos deletados.",
            "A aplicaÃ§Ã£o de mÃ©todos cientÃ­ficos para que a prova suporte o contraditÃ³rio judicial.",
            "O uso exclusivo de ferramentas pagas de alta tecnologia.",
            "A identificaÃ§Ã£o imediata do culpado sem necessidade de processo."
        ],
        dica: "Lembre-se: Forense vem de FÃ³rum.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 2",
        subtitulo: "Unidade 01: PrincÃ­pio de Locard",
        pergunta: "Sobre o PrincÃ­pio de Locard aplicado ao mundo digital, qual afirmaÃ§Ã£o Ã© correta?",
        opcoes: [
            "Todo contato ou aÃ§Ã£o deixa um rastro, mesmo que seja o registro da prÃ³pria deleÃ§Ã£o.",
            "No ambiente digital Ã© impossÃ­vel deixar rastros.",
            "O rastro digital sÃ³ existe se o usuÃ¡rio estiver conectado Ã  internet.",
            "Rastros digitais sÃ£o apagados permanentemente ao desligar o PC."
        ],
        dica: "Todo contato deixa um rastro - logs, metadados, temporÃ¡rios.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 3",
        subtitulo: "Unidade 01: Ã‰tica",
        pergunta: "Qual Ã© a principal responsabilidade Ã©tica do perito digital?",
        opcoes: [
            "Garantir a condenaÃ§Ã£o do suspeito a qualquer custo.",
            "Analisar todos os arquivos pessoais, mesmocom os irrelevantes ao caso.",
            "Manter a imparcialidade, limitando-se aos fatos tÃ©cnicos extraÃ­veis.",
            "Alterar a evidÃªncia para tornÃ¡-la mais compreensÃ­vel."
        ],
        dica: "O perito trabalha para a verdade, nÃ£o para a polÃ­cia ou defesa.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 4",
        subtitulo: "Unidade 01: Reprodutibilidade",
        pergunta: "Por que a perÃ­cia digital Ã© um processo crÃ­tico em termos de 'reprodutibilidade'?",
        opcoes: [
            "Porque a evidÃªncia Ã© frÃ¡gil e pode ser alterada no primeiro contato.",
            "Porque os peritos nÃ£o utilizam o mÃ©todo cientÃ­fico.",
            "Porque cada perito possui sua prÃ³pria interpretaÃ§Ã£o pessoal.",
            "Porque as ferramentas mudam de resultado toda vez que sÃ£o usadas."
        ],
        dica: "VocÃª sÃ³ tem UMA chance de coletar a RAM ou o local de crime.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 5",
        subtitulo: "Unidade 01: Validade JurÃ­dica",
        pergunta: "O que define a 'validade jurÃ­dica' de uma evidÃªncia digital?",
        opcoes: [
            "O fato de ter sido encontrada por um policial.",
            "A quantidade de gigabytes de dados coletados.",
            "O uso de criptografia para esconder a evidÃªncia da defesa.",
            "A comprovaÃ§Ã£o de sua integridade e preservaÃ§Ã£o da cadeia de custÃ³dia."
        ],
        dica: "Sem Cadeia de CustÃ³dia, Ã© lixo jurÃ­dico.",
        respostaCorreta: 3
    }
},

// --- UNIDADE 02 E 03: PROCEDIMENTOS E ESTRUTURAS ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 6",
        subtitulo: "Unidade 02: ISO 27037",
        pergunta: "Segundo a ISO/IEC 27037, quem Ã© o responsÃ¡vel pela preservaÃ§Ã£o inicial no local?",
        opcoes: [
            "Juiz de InstruÃ§Ã£o Forense.",
            "Interventor em EvidÃªncia Digital (DEFR).",
            "Especialista em EvidÃªncia Digital (DES).",
            "Administrador de Sistemas da Empresa."
        ],
        dica: "First Responder - primeiro a chegar.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 7",
        subtitulo: "Unidade 02: Cadeia de CustÃ³dia",
        pergunta: "Por que a 'Cadeia de CustÃ³dia' Ã© o coraÃ§Ã£o da perÃ­cia?",
        opcoes: [
            "Porque permite cobrar mais caro pelo serviÃ§o.",
            "Porque serve para criptografar os dados.",
            "Porque garante a rastreabilidade, impedindo alegaÃ§Ãµes de plantaÃ§Ã£o de provas.",
            "Porque define quais crimes sÃ£o mais importantes."
        ],
        dica: "O pecado capital forense Ã© quebrar a Cadeia.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 8",
        subtitulo: "Unidade 03: Slack Space",
        pergunta: "O que caracteriza o 'Slack Space'?",
        opcoes: [
            "EspaÃ§o entre o fim do arquivo e o final do cluster alocado.",
            "EspaÃ§o livre no disco para novos arquivos.",
            "Uma partiÃ§Ã£o oculta para criptografia.",
            "Ãrea do disco com danos fÃ­sicos (Bad Sectors)."
        ],
        dica: "O espaÃ§o desperdiÃ§ado onde arquivos deletados vivem.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 9",
        subtitulo: "Unidade 03: TRIM",
        pergunta: "Qual o desafio introduzido pelo comando TRIM em SSDs?",
        opcoes: [
            "Aumenta o tamanho dos arquivos.",
            "Criptografa o disco automaticamente.",
            "Limpa fisicamente setores deletados, impedindo a recuperaÃ§Ã£o.",
            "Impede o uso de Write Blockers."
        ],
        dica: "SSDs modernos limpam sozinhos para ganhar performance.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 10",
        subtitulo: "Unidade 03: NTFS",
        pergunta: "Onde ficam os metadados (nome, datas) em um sistema NTFS?",
        opcoes: [
            "No BIOS do computador.",
            "Na MFT (Master File Table).",
            "No arquivo Pagefile.sys.",
            "Dentro do Payload do arquivo."
        ],
        dica: "Ã‰ uma tabela mestra de arquivos.",
        respostaCorreta: 1
    }
},

// --- UNIDADE 04: LOGS E MEMÃ“RIA ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simul ado Forense - QuestÃ£o 11",
        subtitulo: "Unidade 04: Volatilidade",
        pergunta: "Por que a Ordem de Volatilidade Ã© crucial?",
        opcoes: [
            "Para coletar primeiro o que permanece mais tempo no disco.",
            "Para garantir que arquivos grandes sejam copiados primeiro.",
            "Para priorizar dados que desaparecem rÃ¡pido (RAM, conexÃµes).",
            "Para evitar que o suspeito apague arquivos fÃ­sicos."
        ],
        dica: "RAM antes de HD - o que evapora primeiro.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 12",
        subtitulo: "Unidade 04: RAM",
        pergunta: "O que se encontra no Dump de RAM que nÃ£o estÃ¡ no HD?",
        opcoes: [
            "Chaves de criptografia ativas e processos ocultos.",
            "Fotos salvas na pasta do usuÃ¡rio.",
            "HistÃ³rico de e-mails de anos atrÃ¡s.",
            "Marca e modelo do processador."
        ],
        dica: "A RAM Ã© o presente, o disco Ã© o passado.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 13",
        subtitulo: "Unidade 04: Windows Logs",
        pergunta: "Qual log do Windows identifica falhas de autenticaÃ§Ã£o?",
        opcoes: [
            "Application Log.",
            "Security Log.",
            "System Log.",
            "Setup Log."
        ],
        dica: "Auditoria e seguranÃ§a ficam em qual log?",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 14",
        subtitulo: "Unidade 04: BFU",
        pergunta: "O que caracteriza o estado BFU em um smartphone?",
        opcoes: [
            "O modo aviÃ£o estÃ¡ ativado.",
            "A bateria estÃ¡ abaixo de 5%.",
            "O aparelho foi reiniciado e a criptografia ainda protege os dados.",
            "O aparelho jÃ¡ foi desbloqueado uma vez."
        ],
        dica: "Before First Unlock - antes do primeiro desbloqueio.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 15",
        subtitulo: "Unidade 04: Faraday",
        pergunta: "Qual a funÃ§Ã£o da Capa de Faraday?",
        opcoes: [
            "Permitir chamadas nÃ£o rastreadas.",
            "Criptografar o celular automaticamente.",
            "Aumentar a duraÃ§Ã£o da bateria.",
            "Isolar sinais de RF para impedir apagamento remoto (Wipe)."
        ],
        dica: "Bloqueio total de sinais.",
        respostaCorreta: 3
    }
},

// --- UNIDADE 05: FERRAMENTAS ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 16",
        subtitulo: "Unidade 05: IPED",
        pergunta: "Qual ferramenta nacional da PF foca em Big Data Forense?",
        opcoes: [
            "IPED.",
            "Magnet AXIOM.",
            "Cellebrite.",
            "Volatility."
        ],
        dica: "Orgulho nacional da PolÃ­cia Federal.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 17",
        subtitulo: "Unidade 05: Write Blocker",
        pergunta: "O que um Write Blocker faz fisicamente?",
        opcoes: [
            "Aumenta a velocidade de cÃ³pia.",
            "Permite leitura, mas bloqueia eletronicamente qualquer escrita.",
            "Apaga vÃ­rus do HD.",
            "Quebra a senha do Windows."
        ],
        dica: "Hardware obrigatÃ³rio para nÃ£o contaminar a prova.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 18",
        subtitulo: "Unidade 05: Hunchly",
        pergunta: "Para que serve o Hunchly?",
        opcoes: [
            "Extrair iPhones em BFU.",
            "Analisar logs de servidores Linux.",
            "Preservar evidÃªncias web durante a navegaÃ§Ã£o.",
            "Recuperar fotos de cartÃµes SD."
        ],
        dica: "Web Forensics - prova online que nÃ£o desaparece.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 19",
        subtitulo: "Unidade 05: Autopsy",
        pergunta: "A ferramenta Autopsy Ã© conhecida por ser:",
        opcoes: [
            "Um hardware de clonagem de discos.",
            "Um antivÃ­rus russo.",
            "Uma suÃ­te open-source poderosa com interface grÃ¡fica.",
            "A Ãºnica capaz de invadir iCloud."
        ],
        dica: "Open-source, amigÃ¡vel e extensÃ­vel.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 20",
        subtitulo: "Unidade 05: DVR Forensics",
        pergunta: "Para analisar sistemas de arquivos proprietÃ¡rios de DVR, usa-se:",
        opcoes: [
            "FormataÃ§Ã£o do disco em NTFS.",
            "Placa lÃ³gica de computador comum.",
            "Ferramentas especializadas em DVR Forensics.",
            "MicroscÃ³pio eletrÃ´nico."
        ],
        dica: "CFTV tem sistema proprietÃ¡rio.",
        respostaCorreta: 2
    }
},

// --- UNIDADE 06: INVESTIGAÃ‡ÃƒO E RELATÃ“RIO ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 21",
        subtitulo: "Unidade 06: AnÃ¡lise de VÃ­nculos",
        pergunta: "O que define a tÃ©cnica de 'AnÃ¡lise de VÃ­nculos'?",
        opcoes: [
            "Verificar o Hash da cÃ³pia.",
            "Instalar links de internet rÃ¡pidos.",
            "Mapear relacionamentos e redes criminosas.",
            "Conectar cabos USB no dispositivo."
        ],
        dica: "Essencial no GAECO para organizaÃ§Ãµes criminosas.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 22",
        subtitulo: "Unidade 06: Quesitos",
        pergunta: "Qual a finalidade dos Quesitos?",
        opcoes: [
            "Nomes dos suspeitos presos.",
            "Perguntas formuladas pelo juiz/partes que o perito deve responder.",
            "Ferramentas de software escolhidas.",
            "Erros encontrados na RAM."
        ],
        dica: "O limite da atuaÃ§Ã£o do perito.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 23",
        subtitulo: "Unidade 06: Timeline",
        pergunta: "O que significa 'Time-lining'?",
        opcoes: [
            "Definir prazo de entrega do laudo.",
            "Contar o tempo que o suspeito usou o PC.",
            "Ajustar o relÃ³gio do sistema.",
            "Organizar artefatos em sequÃªncia cronolÃ³gica dos fatos."
        ],
        dica: "A narrativa que convence o magistrado.",
        respostaCorreta: 3
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 24",
        subtitulo: "Unidade 06: Linguagem",
        pergunta: "Por que evitar 'tecniquÃªs' excessivo no laudo?",
        opcoes: [
            "Porque a ABNT proÃ­be estrangeirismos.",
            "Para a defesa nÃ£o conseguir contestar.",
            "Porque o Juiz precisa entender o fato para decidir.",
            "Para esconder falta de conhecimento."
        ],
        dica: "Traduzir offset hexadecimal em evidÃªncia de acesso.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 25",
        subtitulo: "Unidade 06: Metodologia",
        pergunta: "O que deve constar na seÃ§Ã£o de Metodologia?",
        opcoes: [
            "ConfissÃ£o do suspeito.",
            "DescriÃ§Ã£o das ferramentas e tÃ©cnicas para garantir repetibilidade.",
            "Lista de policiais da operaÃ§Ã£o.",
            "OpiniÃ£o sobre o carÃ¡ter do investigado."
        ],
        dica: "Quais ferramentas e tÃ©cnicas foram usadas?",
        respostaCorreta: 1
    }
},

// --- EXTRAS DE FECHAMENTO ---
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 26",
        subtitulo: "Unidade 06: Laudo vs Parecer",
        pergunta: "Qual a diferenÃ§a entre Laudo e Parecer TÃ©cnico?",
        opcoes: [
            "Laudo Ã© do perito oficial; Parecer Ã© do assistente tÃ©cnico das partes.",
            "Laudo Ã© Ã  mÃ£o e Parecer Ã© digitado.",
            "Parecer tem mais valor que o Laudo.",
            "Laudo nÃ£o pode ter imagens."
        ],
        dica: "Perito oficial vs assistente tÃ©cnico.",
        respostaCorreta: 0
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 27",
        subtitulo: "Unidade 06: Nuvem",
        pergunta: "Desafio de dados na nuvem no relatÃ³rio:",
        opcoes: [
            "Falta de sistema de arquivos na nuvem.",
            "JurisdiÃ§Ã£o e obtenÃ§Ã£o legal de dados em outros paÃ­ses.",
            "Cor dos Ã­cones dos arquivos.",
            "Imprimir todos os arquivos para o juiz."
        ],
        dica: "Dados em servidores globais exigem cooperaÃ§Ã£o internacional.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 28",
        subtitulo: "Unidade 06: Fase de AnÃ¡lise",
        pergunta: "O que caracteriza a fase de AnÃ¡lise?",
        opcoes: [
            "Levar computadores ao laboratÃ³rio.",
            "Limpeza fÃ­sica do hardware.",
            "Processo intelectual de interpretar dados para responder ao caso.",
            "Sorteio de quem escreve o laudo."
        ],
        dica: "A fase intelectual que cruza logs e metadados.",
        respostaCorreta: 2
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 29",
        subtitulo: "Unidade 06: Hash",
        pergunta: "Por que o 'Efeito Avalanche' Ã© importante no Hash?",
        opcoes: [
            "Recupera arquivos apagados.",
            "Garante que 1 bit alterado mude todo o Hash final.",
            "Faz o PC travar em caso de erro.",
            "Deleta arquivos duplicados."
        ],
        dica: "A impressÃ£o digital dos arquivos.",
        respostaCorreta: 1
    }
},
{
    tipo: "quiz",
    conteudo: {
        titulo: "Simulado Forense - QuestÃ£o 30",
        subtitulo: "Unidade 06: Imparcialidade",
        pergunta: "Atitude do perito ao achar prova de inocÃªncia:",
        opcoes: [
            "Ignorar para nÃ£o atrapalhar a polÃ­cia.",
            "Apagar a evidÃªncia.",
            "Relatar com a mesma clareza da prova de culpa.",
            "Cobrar extra da defesa."
        ],
        dica: "O perito trabalha para a evidÃªncia, nÃ£o para a polÃ­cia.",
        respostaCorreta: 2
    }
}

